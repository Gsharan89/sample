package org.sharan.opiant;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OpiantApplicationTests {

	@Test
	void contextLoads() {
	}

}
